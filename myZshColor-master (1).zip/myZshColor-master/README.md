# myZshColor

.zshrc zsh配置文件
bulletxxxx --- 人家的主题,不过我改了点颜色
Untitledxxxx iterm2 的颜色配置

# vsc 设置
// Place your settings in this file to overwrite default and user settings.
{
    "files.exclude": {
        "**/.git": true,
        "**/.DS_Store": true,
        "**/*.map": true,
        "**/*.js": {
            "when": "$(basename).ts"
        }
    },
    "javascript.validate.enable": false,
    "eslint.enable": true,
    "files.associations": {
        "*.js": "javascriptreact"
    },
    "editor.minimap.enabled": false,
    "workbench.colorTheme": "Atom One Dark",
    "workbench.iconTheme": "vs-seti",
    "css.validate": false,
    "window.nativeTabs": false,
    "workbench.editor.swipeToNavigate": false,
    "editor.snippetSuggestions": "top",
    "prettier.useTabs": false,
    "prettier.singleQuote": true,
    "prettier.jsxBracketSameLine": true,
    "prettier.semi": false,
    "path-intellisense.extensionOnImport": true,
    "path-intellisense.mappings": {
        "/": "${workspaceRoot}",
         "shared": "${workspaceRoot}/src/appSettings",
        "assets":"${workspaceRoot}/src/assets",
        "utils": "${workspaceRoot}/src/utils",
        "modules": "${workspaceRoot}/src/routes",
        "layouts": "${workspaceRoot}/src/layouts",
        "constants":"${workspaceRoot}/src/constants",
        "store":"${workspaceRoot}/src/model/store"
    },
    "editor.multiCursorModifier": "ctrlCmd",
    "rust.mode": "legacy",
    "terminal.external.osxExec": "iTerm.app",
    "rust.executeCargoCommandInTerminal": true,
    "terminal.integrated.fontFamily": "Monaco for Powerline",
    "terminal.integrated.fontSize": 14,
    "rust.rustup": {
        "toolchain": "stable-x86_64-apple-darwin"
    },
    "prettier.eslintIntegration": true
}
